package images.model.pattern;

import images.beans.IPatternBean;

/**
 * Utility to manipulate the buffered image, functionalities included are adding
 * character to image, removing color from image.
 * 
 * @author dileepshah
 *
 */
public interface IPatternManipulate {
  /**
   * Replaces a particular color with new replacing color from the image.
   * 
   * @param patternBean          the image object
   * @param toReplaceColor the color to be replaced
   * @param replacingRGB   the new color
   * @return the new image updated
   */
  IPatternBean replaceColor(IPatternBean patternBean, String toReplaceColor, String replacingRGB);

}
