
package images.view.component;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

/**
 * Image panel for Original image.
 * 
 * @author dileepshah
 */
public class OriginalImagePanel extends javax.swing.JPanel {

  /**
   * Generated serialVersionUID.
   */
  private static final long serialVersionUID = -9121992337882639885L;
  // private JLabel originalImageL;
  private final JScrollPane originalImageSP;
  private final JLabel labelImage;

  /**
   * Creates new OriginalImagePanel.
   */
  public OriginalImagePanel() {
    labelImage = new JLabel();
    originalImageSP = new JScrollPane();
    initComponents();
  }

  private void initComponents() {

    // originalImageL = new JLabel();

    setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
    setPreferredSize(new java.awt.Dimension(500, 600));

    originalImageSP.setBorder(BorderFactory.createTitledBorder("Original Image"));
    originalImageSP.setAutoscrolls(true);
    originalImageSP.setSize(new Dimension(500, 450));
    originalImageSP.setVisible(true);
    originalImageSP.setViewportView(labelImage);
    this.setVisible(false);
    // originalImageL.setText("Original Image");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
    this.setLayout(layout);
    javax.swing.GroupLayout originalImagePanelLayout = new javax.swing.GroupLayout(this);
    this.setLayout(originalImagePanelLayout);
    originalImagePanelLayout.setHorizontalGroup(
        originalImagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 372, Short.MAX_VALUE).addComponent(originalImageSP));
    originalImagePanelLayout.setVerticalGroup(
        originalImagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 424, Short.MAX_VALUE).addComponent(originalImageSP));
  }

  /**
   * Set the image to panel.
   * 
   * @param image the image
   */
  public void setImage(BufferedImage image) {
    if (image == null) {
      return;
    }
    ImageIcon icon = new ImageIcon(image);
    labelImage.setIcon(icon);
    Dimension dimension = new Dimension(Math.min(500, image.getWidth()),
        Math.min(480, image.getHeight()));
    this.originalImageSP.setSize(dimension);
    this.setOpaque(false);
    this.setVisible(true);
    this.repaint();
    this.updateUI();
  }

}
