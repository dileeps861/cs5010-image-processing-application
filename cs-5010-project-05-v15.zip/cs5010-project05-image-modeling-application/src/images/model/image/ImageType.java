package images.model.image;

/**
 * Defines the Image Types.
 */
public enum ImageType {
  STANDARD
}
