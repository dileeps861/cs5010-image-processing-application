package images.model.kernel;

/**
 * Defines the Kernel Types.
 */
public enum KernelType {
  FIVE_PIXEL_SHARPEN, THREE_PIXEL_BLUR
}
