package images.model.dethering;

/**
 * Enum to represent DitherImage type.
 * 
 * @author dileepshah
 *
 */
public enum DitherImageType {
  FLOYD_STEINBERG
}
