
import images.model.IModel;
import images.model.Model;
import images.controller.CommandController;
import images.controller.CommandControllerImpl;
import images.controller.CommandGenerator;
import images.controller.CommandGeneratorImpl;
import images.controller.ImageProcessingController;
import images.controller.ImageProcessingControllerImpl;
import images.utilities.ClientUtility;
import images.utilities.ClientUtilityImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Driver class to run the programm.
 * 
 * @author dileepshah
 *
 */
public class DriverClass {

  /**
   * Main method to run the program.
   * 
   * @param args string arguments
   */
  public static void main(String[] args) {
    CommandController commandController = new CommandControllerImpl();

    String fileName = args[0];
    System.out.println("Reading the commands from file: " + fileName);
    System.out.println(
        "Your commands are being processed...\n"
        + "Please wait for a while before I finish your given tasks... ");

    File file = new File("./" + fileName);
    try (InputStream inputStream = new FileInputStream(file)) {
      InputStreamReader in = new InputStreamReader(inputStream);
      StringBuilder out = new StringBuilder();
      CommandGenerator commandGenerator = new CommandGeneratorImpl();

      ClientUtility clientUtility = new ClientUtilityImpl();
      IModel model = new Model();
      ImageProcessingController controller = new ImageProcessingControllerImpl(in, out,
          commandController, commandGenerator, clientUtility, model);
      controller.start();
      System.out.println(out.toString());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
