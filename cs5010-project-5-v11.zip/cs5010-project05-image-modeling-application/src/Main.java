
import images.controller.*;
import images.model.IModel;
import images.model.Model;
import images.utilities.ClientUtility;
import images.utilities.ClientUtilityImpl;
import images.view.IImageProcessingView;
import images.view.IPViewJFrame;
import images.view.UIActionListener;

/**
 * Main class to run view.
 * 
 * @author dileepshah
 *
 */
public class Main {

  /**
   * Main method, boot-loader of the program.
   * 
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub

    // Model of the project.
    CommandController commandController = new CommandControllerImpl();

    // Readable object for controller
    // StringReader in = new StringReader("");

    // Appendable object for the confirmation messages.
    // StringBuilder out = new StringBuilder();

    // Command generator to generate command objects from given string command
    CommandGenerator commandGenerator = new CommandGeneratorImpl();

    // Client utility object, handles file handling tasks.
    ClientUtility clientUtility = new ClientUtilityImpl();

    // Model
    IModel model = new Model();
    
    // The controller cum observer.
    UIController controller = new UIController(
        commandController, commandGenerator, clientUtility, model);

    IImageProcessingView view = new IPViewJFrame("Image Processing");
    // Set the view in the controller
    // view.addActionListener(new UIActionListener());
    controller.setView(view);
    view.addActionListener(new UIActionListener(controller));
  }

}
