package images.controller;

import images.view.IImageProcessingView;

import java.awt.image.BufferedImage;



/**
 * This interface represents a set of features that the image processing program
 * offers. Each feature is exposed as a function in this interface. This
 * function works as observer between view and controller. If anything is
 * changed from view then controller takes it from the model. And anything
 * returned from model, that will be rendered by view from here. View can
 * implement these features in whichever way they like to.
 */
public interface Features {

  /**
   * Exit the program.
   */
  void exitProgram();

  /**
   * Process the image except for pattern generation.
   */
  void processImage();

  /**
   * Generate the pattern of image.
   */
  void generatePatternWithCustomColors();

  /**
   * Callback method to load the image.
   */
  void loadImage();

  /**
   * Save the image to file system.
   */
  void saveImage();

  /**
   * Save the file to file system.
   */
  void saveFile();
  
  /**
   * Save the file to file system.
   * 
   * @param command the command for controller
   */
  void saveFile(String command);

  /**
   * Sets the controller to the observer.
   *
   * @param view the view
   */
  void setView(IImageProcessingView view);

  /**
   * Callback method to show image to view.
   * 
   * @param image the image to show
   */
  void showImage(BufferedImage image);

  /**
   * Clears the processed Image to original image.
   * 
   */
  void resetProcessing();

  /**
   * Callback method to show pattern to view.
   */
  void runBatchFile();

  /**
   * Callback method to replace one color of the pattern.
   */
  void replacePatternColor();
  
  /**
   * Callback method to select replacing color of the pattern.
   */
  void replacePatternColorSelection();

  /**
   * Callback method to replace one color of the pattern.
   */
  void removePatternColor();
  
  /**
   * Callback method to generate pattern with custom text.
   */
  void generatePatternWithCustomText();
  
  /**
   * Show message to UI.
   * @param message the message to show
   */
  void showMessage(String message);
  
  /**
   * Feature to handle editing commands.
   * @param command the command string
   */
  void editOptionSelection(String command);
  
  /**
   * Feature to handle command of pattern with custom color menu selection.
   */
  void patternWithCustomColorSelected();
  
  
  /**
   * Feature to handle command of pattern with custom text menu selection.
   */
  void patternWithCustomTextSelected();

}
