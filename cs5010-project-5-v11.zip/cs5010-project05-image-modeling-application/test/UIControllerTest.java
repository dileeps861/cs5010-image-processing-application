
import static org.junit.Assert.assertEquals;

import images.beans.IPatternBeanMock;
import images.constants.EditingOptions;
import images.controller.CommandController;
import images.controller.CommandControllerImpl;
import images.controller.CommandGenerator;
import images.controller.CommandGeneratorImpl;
import images.controller.Features;
import images.controller.UIController;
import images.model.IModelMock;
import images.utilities.ClientUtility;
import images.utilities.MockClientUtility;
import images.view.IImageProcessingViewMock;
import org.junit.Before;
import org.junit.Test;

import java.awt.image.BufferedImage;

/**
 * Test class to test UI controller.
 */
public class UIControllerTest {
  private Features feature;
  private CommandController commandController;
  private CommandGenerator commandGenerator;
  private IModelMock model;
  private IImageProcessingViewMock view;
  private StringBuilder out;
  private ClientUtility clientUtility;

  @Before
  public void setUp() throws Exception {
    out = new StringBuilder();
    commandController = new CommandControllerImpl();
    commandGenerator = new CommandGeneratorImpl();
    clientUtility = new MockClientUtility(out);
    model = new IModelMock(out);
    view = new IImageProcessingViewMock(out);
    UIController controller = new UIController(commandController, commandGenerator, clientUtility,
        model);
    controller.setView(view);
    feature = controller;
  }

  @Test
  public void setView() {
    UIController controller = new UIController(commandController, commandGenerator, clientUtility,
        model);
    controller.setView(view);
    StringBuilder expectedValue = new StringBuilder(
        "UIController{commandController=CommandControllerImpl{commands=[]}, ");
    expectedValue
        .append("commandGenerator=CommandGeneratorImpl{}, clientUtility=MockClientUtility{},")
        .append(" view=IImageProcessingViewMock{}, model=IModelMock{}}");
    assertEquals(expectedValue.toString(), controller.toString());
  }

  /**
   * Test if error thrown in the form of message if process image called without
   * calling loadImage().
   */
  @Test
  public void processImageWithoutImage() {
    feature.editOptionSelection(EditingOptions.BLUR.toString());
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() Invoked")
        .append("IImageProcessingViewMock.setMessage() Invoked")
        .append("\nYou must load the image before proceeding to process the image.");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if error thrown in the form of message if process image called without
   * select any editing option.
   */
  @Test
  public void processImageWithoutOption() {
    // feature.editOptionSelection(EditingOptions.BLUR.toString());
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.getLoadedImage() Invoked")
        .append("IImageProcessingViewMock.setMessage() Invoked")
        .append("\nYou must select editing option before processing the image.");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if blur option works correctly.
   */
  @Test
  public void processImageBlurTest() {
    feature.editOptionSelection(EditingOptions.BLUR.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage").append("\nIModelMock.blurImage() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if gray sharpen works correctly.
   */
  @Test
  public void processImageSharpenTest() {
    feature.editOptionSelection(EditingOptions.SHARPEN.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage").append("\nIModelMock.sharpenImage() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if Grayscale option works correctly.
   */
  @Test
  public void processImageGrayscaleTest() {
    feature.editOptionSelection(EditingOptions.GRAYSCALE.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIModelMock.transformImageColorToGrayScale() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if sepiatone option works correctly.
   */
  @Test
  public void processImageSepiaToneTest() {
    feature.editOptionSelection(EditingOptions.SEPIA_TONE.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIModelMock.transformImageColorToSepiaTone() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if dither option throws error if now number of colors provided.
   */
  @Test
  public void processImageDitherWrongCommandTest() {
    feature.editOptionSelection(EditingOptions.DITHER.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIImageProcessingViewMock.setMessage() Invoked").append(
            "\nCommandGeneratorImpl: Dither image must be in format \"dither " + "<noOfColors>\"");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if dither option works correctly.
   */
  @Test
  public void processImageDitherTest() {
    feature.editOptionSelection(EditingOptions.DITHER.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    view.setUserProvideSelectionValues("2");
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage").append("\nIModelMock.ditherImage() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if pixelate option throws error if the not given.
   */
  @Test
  public void processImagePixelateWrongCommandTest() {
    feature.editOptionSelection(EditingOptions.PIXELATE.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIImageProcessingViewMock.setMessage() Invoked").append(
            "\nCommandGeneratorImpl: Number of squares must be specified and must be more than zero.");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if generate pixelate option works correctly.
   */
  @Test
  public void processImagePixelateTest() {
    feature.editOptionSelection(EditingOptions.PIXELATE.toString());
    view.setUserProvideSelectionValues("50");
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.resetPattern() Invoked")
        .append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage").append("\nIModelMock.pixelateImage() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")
        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if pixelate option throws error if the user value not given.
   */
  @Test
  public void processImagePatternWrongCommandTest() {
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIImageProcessingViewMock.setMessage() Invoked").append(
            "\nPixelation/ Mosaic/ Dither/ Pattern user provided value must be specified and must be a non zero number. Provided: null");
    assertEquals(expectedValue.toString(), out.toString());

  }

  /**
   * Test if pixelate option throws error if user value is empty.
   */
  @Test
  public void processImagePatternEmptyUservalueTest() {
    // Test for empty user value provided
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUserProvideSelectionValues("");
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() Invoked")
        .append("IImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.setMessage() Invoked")
        .append("\nPixelation/ Mosaic/ Dither/ Pattern user provided value ")
        .append("must be specified and must be a non zero number. Provided: ");

    assertEquals(expectedValue.toString(), out.toString());

  }

  /**
   * Test if pixelate option throws error if user value is blank.
   */
  @Test
  public void processImagePatternBlankUservalueTest() {
    // Test for blank user value provided
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUserProvideSelectionValues(" ");
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() Invoked")
        .append("IImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.setMessage() Invoked\n")
        .append("Pixelation/ Mosaic/ Dither/ Pattern user provided value")
        .append(" must be specified and must be a non zero number. Provided:  ");
    assertEquals(expectedValue.toString(), out.toString());

  }

  /**
   * Test if generate pattern option throws error if user value is non-numerical.
   */
  @Test
  public void processImagePatternNonNumericUserValueTest() {

    // Test for non numerical user value provided
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUserProvideSelectionValues("12a");
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.setMessage() Invoked")
        .append("\nPixelation/ Mosaic/ Dither/ Pattern user provided value must be specified "
            + "and must be a non zero number. Provided: 12a");
    assertEquals(expectedValue.toString(), out.toString());

  }

  /**
   * Test if generate pattern option throws error if pattern bean generated is
   * null.
   */
  @Test
  public void processImagePatternPatternBeanNull() {
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUserProvideSelectionValues("50");
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIModelMock.generatePattern() Invoked")
        .append("\nIImageProcessingViewMock.setMessage() Invoked")
        .append("\nPattern could not be generated.");
    assertEquals(expectedValue.toString(), out.toString());
  }

  /**
   * Test if generate pixelate option works correctly.
   */
  @Test
  public void processImagePatternTest() {
    feature.editOptionSelection(EditingOptions.GENERATE_PATTERN.toString());
    view.setUserProvideSelectionValues("50");
    model.setPatternBean(new IPatternBeanMock());
    view.setUploadedImage(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB));
    feature.processImage();
    StringBuilder expectedValue = new StringBuilder();
    expectedValue.append("IImageProcessingViewMock.setSelectedMenu() Invoked")
        .append("IImageProcessingViewMock.setProcessingValuesVisible() Invoked")
        .append("IImageProcessingViewMock.getLoadedImage() ")
        .append("InvokedIImageProcessingViewMock.getUserProvideSelectionValues() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked")
        .append("Invoked MockClientUtility.getImage")
        .append("\nIModelMock.generatePattern() Invoked")
        .append("\nInvoked MockClientUtility.getBufferedImage")

        .append("\nIImageProcessingViewMock.showProcessedImage() Invoked")
        .append("IImageProcessingViewMock.showPattern() Invoked")
        .append("IImageProcessingViewMock.toggleRemoveColorButton() Invoked")
        .append("IImageProcessingViewMock.toggleReplaceColorButton() Invoked");
    assertEquals(expectedValue.toString(), out.toString());
  }

  @Test
  public void setActionListener() {
    // TODO
  }

  @Test
  public void runBatchFile() {
    // TODO
  }

  @Test
  public void testRunBatchFile() {
    // TODO
  }

  @Test
  public void testSaveImage() {
    // TODO
  }

  @Test
  public void testSaveFile() {
    // TODO
  }

  @Test
  public void resetProcessing() {
    // TODO
  }

  @Test
  public void generatePatternWithCustomText() {
    // TODO
  }

  @Test
  public void patternWithCustomColorSelected() {
    // TODO
  }

  @Test
  public void patternWithCustomTextSelected() {
    // TODO
  }

  @Test
  public void replacePatternColorSelection() {
    // TODO
  }
}