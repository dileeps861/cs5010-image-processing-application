package images.model.filter;

/**
 * Image filter type.
 */
public enum ImageFilterType {
  BLUR, SHARPEN
}
