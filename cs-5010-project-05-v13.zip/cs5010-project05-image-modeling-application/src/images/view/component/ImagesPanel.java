
package images.view.component;

import javax.swing.GroupLayout;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

/**
 * The image panel to combine original image and processed image panel.
 * 
 * @author dileepshah
 */
public class ImagesPanel extends JPanel {

  /**
   * Generated serialVersionUID.
   */
  private static final long serialVersionUID = -4370388238489990172L;

  private JPanel originalImagePanel;

  /**
   * Creates the ImagesPanel object.
   */
  public ImagesPanel() {
    initComponents();
  }

  private void initComponents() {


    originalImagePanel = new JPanel();

    originalImagePanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED));

    GroupLayout originalImagePanelLayout = new GroupLayout(originalImagePanel);
    originalImagePanel.setLayout(originalImagePanelLayout);
    originalImagePanelLayout.setHorizontalGroup(originalImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 372, Short.MAX_VALUE));
    originalImagePanelLayout.setVerticalGroup(originalImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 424, Short.MAX_VALUE));
    
    JPanel combinedPanel = new JPanel();
    GroupLayout combinedPanelLayout = new GroupLayout(combinedPanel);
    combinedPanel.setLayout(combinedPanelLayout);
    combinedPanelLayout
        .setHorizontalGroup(combinedPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(combinedPanelLayout.createSequentialGroup().addContainerGap().addComponent(
                originalImagePanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                GroupLayout.PREFERRED_SIZE)));
    combinedPanelLayout
        .setVerticalGroup(combinedPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(combinedPanelLayout.createSequentialGroup().addContainerGap()
                .addGroup(combinedPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(originalImagePanel, GroupLayout.DEFAULT_SIZE,
                        GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap()));

    GroupLayout layout = new GroupLayout(this);
    this.setLayout(layout);
    
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup().addContainerGap()
            .addComponent(combinedPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
                GroupLayout.PREFERRED_SIZE)
            .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout
            .createSequentialGroup().addContainerGap().addComponent(combinedPanel,
                GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addContainerGap()));
  }

  /**
   * Add original and processed image to the panel.
   * 
   * @param originalImagePanel  the original image panel
   * @param processedImagePanel the processed image panel
   */
  public void addPanel(JPanel originalImagePanel, JPanel processedImagePanel) {
    if (originalImagePanel == null || processedImagePanel == null) {
      throw new IllegalArgumentException("Image Panels cannot null.");
    }
    GroupLayout originalImagePanelLayout = new GroupLayout(originalImagePanel);
    originalImagePanel.setLayout(originalImagePanelLayout);
    originalImagePanelLayout.setHorizontalGroup(originalImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 425, Short.MAX_VALUE));
    originalImagePanelLayout.setVerticalGroup(originalImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 424, Short.MAX_VALUE));
    this.originalImagePanel = originalImagePanel;

    GroupLayout processedImagePanelLayout = new GroupLayout(processedImagePanel);
    processedImagePanel.setLayout(processedImagePanelLayout);
    processedImagePanelLayout.setHorizontalGroup(processedImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 352, Short.MAX_VALUE));
    processedImagePanelLayout.setVerticalGroup(processedImagePanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 436, Short.MAX_VALUE));

  }

}
