package images.model.transform;

/**
 * Defines the Image transform Types.
 */
public enum ImageColorTransformType {
  SEPIA_TONE, GRAY_SCALE
}
