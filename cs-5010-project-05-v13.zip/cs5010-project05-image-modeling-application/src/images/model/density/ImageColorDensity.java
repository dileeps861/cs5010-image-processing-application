package images.model.density;

import images.model.dethering.DitherImage;
import images.model.image.Image;

/**
 * This interface represents the ImageColorDensity model and provides features
 * like converting color density.
 * 
 * @author dileepshah
 *
 */
public interface ImageColorDensity {
  /**
   * Reduce the colors of image while maintaining the essence and returns new
   * image.
   * 
   * @param image             image to reduce the color
   * @param ditherImageObject the Dithering object to dither the image
   * @return the image reduced color image
   */
  Image reduceColorWithEssence(Image image, DitherImage ditherImageObject)
      throws IllegalArgumentException;
}
