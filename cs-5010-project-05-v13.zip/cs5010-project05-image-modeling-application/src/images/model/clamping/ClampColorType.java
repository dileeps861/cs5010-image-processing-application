package images.model.clamping;

/**
 * Enum represents the ClampColor type.
 * 
 * @author dileepshah
 *
 */
public enum ClampColorType {
  STANDARD
}
