package images.model;

import images.model.image.Image;

/**
 * Abstract class to share the code between Pixelate and pattern generate.
 * 
 * @author dileepshah
 *
 */
public abstract class AbstractPixelatePatternGanerate {

  /**
   * Apply a new color to the super pixel.
   * 
   * @param imageArray       the image array
   * @param image            the image object
   * @param row              the row index
   * @param col              the column index
   * @param heightSquareSize the height of the square
   * @param widthSquareSize  the width of the square
   * @param newColor         the new color to replace
   */
  public void applySuperPixel(int[][][] imageArray, Image image, int row, int col,
      int heightSquareSize, int widthSquareSize, Integer[] newColor) {
    int rowLim = Math.min((row + heightSquareSize), image.getHeight());
    int colLim = Math.min((col + widthSquareSize), image.getWidth());

    for (int i = row; i < rowLim; i++) {
      for (int j = col; j < colLim; j++) {
        int[] rgb = new int[imageArray[i][j].length];
        for (int k = 0; k < rgb.length; k++) {
          rgb[k] = newColor[k];
        }
        imageArray[i][j] = rgb;
      }
    }
  }
}
