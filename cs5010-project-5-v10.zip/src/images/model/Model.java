package images.model;

import images.PatternUtilities;
import images.beans.IPatternBean;
import images.model.chunking.ChunkGeneratorImpl;
import images.model.clamping.ClampColor;
import images.model.clamping.ClampColorFactory;
import images.model.clamping.ClampColorType;
import images.model.density.ImageColorDensityImpl;
import images.model.dethering.DitherImage;
import images.model.dethering.DitherImageFactory;
import images.model.dethering.DitherImageType;
import images.model.filter.ImageFilterFactory;
import images.model.filter.ImageFilterType;
import images.model.image.Image;
import images.model.kernel.KernelFactory;
import images.model.kernel.KernelType;
import images.model.mosaic.MosaicImageImpl;
import images.model.pattern.PatternGeneratorImpl;
import images.model.pattern.PatternManipulate;
import images.model.pixelation.PixelateImageImpl;
import images.model.transform.ImageColorTransformFactory;
import images.model.transform.ImageColorTransformType;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;



/**
 * Central point of contact for whole model. Implements IModel interface.
 * 
 * @author dileepshah
 *
 */
public class Model implements IModel {

  private final ClampColor clamper;

  /**
   * Constructor to create Model object.
   */
  public Model() {
    this.clamper = ClampColorFactory.buildClamp(ClampColorType.STANDARD);
  }

  @Override
  public Image transformImageColorToGrayScale(Image image) {
    return ImageColorTransformFactory
        .buildImageColorTransform(ImageColorTransformType.GRAY_SCALE, clamper)
        .transformImage(image);
  }

  @Override
  public Image transformImageColorToSepiaTone(Image image) {

    return ImageColorTransformFactory
        .buildImageColorTransform(ImageColorTransformType.SEPIA_TONE, clamper)
        .transformImage(image);
  }

  @Override
  public Image blurImage(Image image) {
    return ImageFilterFactory.buildImageFilter(ImageFilterType.BLUR,
        KernelFactory.buildKernel(KernelType.THREE_PIXEL_BLUR), clamper).filterImage(image);

  }

  @Override
  public Image sharpenImage(Image image) {
    return ImageFilterFactory.buildImageFilter(ImageFilterType.SHARPEN,
        KernelFactory.buildKernel(KernelType.FIVE_PIXEL_SHARPEN), clamper).filterImage(image);
  }

  @Override
  public Image ditherImage(Image image, int numberOfColors) {

    DitherImage ditherImage = DitherImageFactory.buildDitherImage(DitherImageType.FLOYD_STEINBERG);
    return new ImageColorDensityImpl(numberOfColors, 256, clamper).reduceColorWithEssence(image,
        ditherImage);
  }

  @Override
  public Image pixelateImage(Image image, int numberOfSquares) {

    return new PixelateImageImpl(numberOfSquares).pixelateImage(image,
        new ChunkGeneratorImpl(numberOfSquares));
  }

  @Override
  public IPatternBean generatePattern(Image image, int numberOfSquares) {
    Map<String, Integer[]> allDmc = PatternUtilities.getDMCMap();
    return generatePattern(image, numberOfSquares, allDmc);
  }

  @Override
  public IPatternBean generatePattern(Image image, int numberOfSquares, Set<String> colors) {
    Map<String, Integer[]> colorsMap = new LinkedHashMap<>();
    Map<String, Integer[]> allDmc = PatternUtilities.getDMCMap();
    for (String key : colors) {
      if (allDmc.containsKey(key)) {
        colorsMap.put(key, allDmc.get(key));
      }
    }
    return generatePattern(image, numberOfSquares, colorsMap);
  }

  private IPatternBean generatePattern(Image image, int numberOfSquares,
      Map<String, Integer[]> colors) {

    return new PatternGeneratorImpl().generatePatternedBean(image,
        new ChunkGeneratorImpl(numberOfSquares), colors);

  }

  @Override
  public Image mosaicImage(Image image, int numberOfSeeds) {

    return new MosaicImageImpl(numberOfSeeds).mosaicImage(image);
  }

  @Override
  public IPatternBean replaceColor(IPatternBean patternBean, String oldColor, String newColor) {
    return new PatternManipulate().replaceColor(patternBean, oldColor, newColor);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Model{");
    sb.append('}');
    return sb.toString();
  }

  @Override
  public IPatternBean addTextToPatternImage(IPatternBean patternBean, String text) {

    return new PatternManipulate().addTextToPatternImage(patternBean, text);
  }

}
