package images.command;


import images.model.IModel;
import images.model.image.Image;

/**
 * Command to execute ImageColorDensity object.
 */
public class DitherImageCommand extends AbstractImageProcessingCommand {

  private final int numberOfcolors;

  /**
   * Constructor to create MosaicImageCommand object.
   * 
   * @param numberOfcolors the number of colors per channel
   * @throws IllegalArgumentException the illegal argument exception
   */
  public DitherImageCommand(IModel model, int numberOfcolors)
      throws IllegalArgumentException {
    super(model);

    this.numberOfcolors = numberOfcolors;

  }

  @Override
  public Image execute(Image image) {
    return getModel().ditherImage(image, numberOfcolors);
  }

  @Override
  public  String toString() {
    final StringBuilder sb = new StringBuilder("DitherImageCommand{");
    sb.append("colorDensity=").append(numberOfcolors);

    sb.append('}');
    return sb.toString();
  }
}
