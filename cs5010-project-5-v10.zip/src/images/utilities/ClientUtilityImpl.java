package images.utilities;



import images.ImageUtilities;
import images.ImageUtilities.Channel;
import images.model.image.Image;
import images.model.image.ImageFactory;
import images.model.image.ImageType;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;

/**
 * Implementation to ClientUtility interface.
 * 
 * @author dileepshah
 *
 */
public final class ClientUtilityImpl implements ClientUtility {

  @Override
  public void saveImageFile( Image image, String fileName)
      throws IllegalArgumentException, IOException {
    validateImageObject(image);
    validateImageSize(image);
    ImageUtilities.writeImage(image.getImage(), image.getWidth(), image.getHeight(), fileName);
  }

  @Override
  public  Image loadImage(String fileName) throws IllegalArgumentException, IOException {
    validateString(fileName);
    int[][][] imageArray = ImageUtilities.readImage(fileName);
    int height = ImageUtilities.getHeight(fileName);
    int width = ImageUtilities.getWidth(fileName);
    return ImageFactory.builImage(ImageType.STANDARD, height, width, imageArray);
  }

  @Override
  public  Readable loadTextFile( String fileName)
      throws IllegalArgumentException, FileNotFoundException {
    validateString(fileName);
    File file = new File(fileName);
    InputStream inputStream = new FileInputStream(file);
    return new InputStreamReader(inputStream);
  }

  @Override
  public void saveTextFile( String data,  String fileName,  Charset encodingType)
      throws IllegalArgumentException, IOException {
    validateString(data);
    validateString(fileName);
    validateImageObject(encodingType);
    Writer stream = new OutputStreamWriter(new FileOutputStream(fileName), encodingType);
    stream.write(data);
    stream.close();

  }

  private void validateString( String arg) throws IllegalArgumentException {
    if (arg == null || arg.isEmpty()) {
      throw new IllegalArgumentException(
          this.getClass().getSimpleName() + ": String argument cannot be null and empty");
    }

  }

  private void validateImageSize( Image image) throws IllegalArgumentException {
    if (image.getHeight() == 0) {
      throw new IllegalArgumentException(
          this.getClass().getSimpleName() + ": Image cannot be null or of size 0");
    }
  }

  @Override
  public  String toString() {
    final StringBuilder sb = new StringBuilder("ClientUtilityImpl{");
    sb.append('}');
    return sb.toString();
  }

  /**
   * Helper validate method to validate image object not null.
   * 
   * @param object arg object
   * @throws IllegalArgumentException the nulll not allowed exception
   */
  private void validateImageObject( Object object) throws IllegalArgumentException {
    if (object == null) {
      throw new IllegalArgumentException("Image Argument must not be null.");
    }
  }

  @Override
  public  BufferedImage getBufferedImage( Image image) {
    validateImageObject(image);

    BufferedImage output = new BufferedImage(image.getWidth(), image.getHeight(),
        BufferedImage.TYPE_INT_RGB);

    int[][][] rgb = image.getImage();
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        int r = rgb[i][j][Channel.RED.ordinal()];
        int g = rgb[i][j][Channel.GREEN.ordinal()];
        int b = rgb[i][j][Channel.BLUE.ordinal()];

        // color is stored in 1 integer, with the 4 bytes storing ARGB in that
        // order. Each of r,g,b are stored in 8 bits (hence between 0 and 255).
        // So we put them all in one integer by using bit-shifting << as below
        int color = (r << 16) + (g << 8) + b;
        output.setRGB(j, i, color);
      }
    }
    return output;

  }

  @Override
  public  Image getImage( BufferedImage bufferedImage) {
    validateImageObject(bufferedImage);
    int[][][] result = new int[bufferedImage.getHeight()][bufferedImage
        .getWidth()][Channel.values().length];

    for (int i = 0; i < bufferedImage.getHeight(); i++) {
      for (int j = 0; j < bufferedImage.getWidth(); j++) {
        int color = bufferedImage.getRGB(j, i);
        Color c = new Color(color);
        result[i][j][Channel.RED.ordinal()] = c.getRed();
        result[i][j][Channel.GREEN.ordinal()] = c.getGreen();
        result[i][j][Channel.BLUE.ordinal()] = c.getBlue();
      }
    }

    return ImageFactory.builImage(ImageType.STANDARD, bufferedImage.getHeight(),
        bufferedImage.getWidth(), result);
  }
}
