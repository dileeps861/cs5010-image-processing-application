package images.view;

import images.beans.IPatternBean;
import images.beans.PatternBean;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Map;
import java.util.Set;



/**
 * Mock of IImageProcessingView interface. Create only for the purpose of
 * testing controller.
 * 
 * @author dileepshah
 *
 */
public class IImageProcessingViewMock implements IImageProcessingView {
  private Appendable appendable;
  private BufferedImage uploadedImage;
  private BufferedImage processedImage;
  private Map<String, Integer> choices;
  private String batchFile;
  private String numberOfChunksForPattern;
  private String toReplaceColor;
  private PatternBean patternBean;
  private String replacingColor;
  private Set<String> selectedColorForPattern;

  public void setSelectedColorForPattern(Set<String> selectedColorForPattern) {
    this.selectedColorForPattern = selectedColorForPattern;
  }

  public void setUploadedImage(BufferedImage uploadedImage) {
    this.uploadedImage = uploadedImage;
  }

  public void setProcessedImage(BufferedImage processedImage) {
    this.processedImage = processedImage;
  }

  public void setChoices(Map<String, Integer> choices) {
    this.choices = choices;
  }

  public void setBatchFile(String batchFile) {
    this.batchFile = batchFile;
  }

  public void setNumberOfChunksForPattern(String numberOfChunksForPattern) {
    this.numberOfChunksForPattern = numberOfChunksForPattern;
  }

  public void setToReplaceColor(String toReplaceColor) {
    this.toReplaceColor = toReplaceColor;
  }

  public void setPatternBean(PatternBean patternBean) {
    this.patternBean = patternBean;
  }

  public void setReplacingColor(String replacingColor) {
    this.replacingColor = replacingColor;
  }

  public void setUserProvideSelectionValues(String userProvideSelectionValues) {
    this.userProvideSelectionValues = userProvideSelectionValues;
  }

  private String userProvideSelectionValues;

  /**
   * Constructor to create object of IImageProcessingViewMock.
   * 
   * @param out the appendable object
   */
  public IImageProcessingViewMock(Appendable out) {
    this.appendable = out;
  }

  @Override
  public void loadImage() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".loadImage() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public void showLoadedImage(BufferedImage image) {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".showLoadedImage() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public void showProcessedImage(BufferedImage image) {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".showProcessedImage() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public String saveFile() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".saveFile() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return null;
  }

  @Override
  public void saveChoices() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".saveChoices() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public Map<String, Integer> getChoices() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getChoices() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return choices;
  }

  @Override
  public BufferedImage getLoadedImage() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getLoadedImage() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return uploadedImage;
  }

  @Override
  public BufferedImage getProcessedImage() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getProcessedImage() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return processedImage;
  }

  @Override
  public void addActionListener(ActionListener actionListener) {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".addActionListener() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public void setMessage(String message) {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".setMessage() " + "Invoked\n");
      this.appendable.append(message);
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public void setProcessingValuesVisible(boolean visibility) {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".setProcessingValuesVisible() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public String getUserProvideSelectionValues() {
    try {
      this.appendable.append(
          this.getClass().getSimpleName() + ".getUserProvideSelectionValues() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return userProvideSelectionValues;
  }

  @Override
  public String getBatchFileText() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getBatchFileText() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return batchFile;
  }

  @Override
  public void setSelectedMenu(String menuCommand) {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".setSelectedMenu() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("IImageProcessingViewMock{");
    sb.append('}');
    return sb.toString();
  }

  @Override
  public void toggleRemoveColorButton(boolean isEnable) {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".toggleRemoveColorButton() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public void toggleReplaceColorButton(boolean isEnable) {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".toggleReplaceColorButton() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public PatternBean getPattern() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getPattern() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

    return patternBean;
  }

  @Override
  public String getReplacingColor() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getReplacingColor() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return replacingColor;
  }

  @Override
  public String getToReplaceColor() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".getToReplaceColor() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return toReplaceColor;
  }

  @Override
  public void showPattern(IPatternBean patternBean) {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".showPattern() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public void resetPattern() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".resetPattern() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public void popupSelectColorDialog() {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".popupSelectColorDialog() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public Set<String> getSelectColorsForPattern() {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".getSelectColorsForPattern() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return selectedColorForPattern;
  }

  @Override
  public String getNumberofChunksForPattern() {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".getNumberOfChunksForPattern() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }
    return numberOfChunksForPattern;
  }

  @Override
  public void popupCustomColorsDialog() {
    try {
      this.appendable
          .append(this.getClass().getSimpleName() + ".popupCustomColorsDialog() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

  @Override
  public void resetProcess() {
    try {
      this.appendable.append(this.getClass().getSimpleName() + ".resetProcess() " + "Invoked");
    } catch (IOException e) {
      throw new AssertionError("Failed to append to appendable.");
    }

  }

}
